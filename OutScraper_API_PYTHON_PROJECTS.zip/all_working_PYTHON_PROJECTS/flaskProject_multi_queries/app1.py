from flask import Flask, render_template, request
import requests
import openai
from bs4 import BeautifulSoup

app = Flask(__name__)

# Set your OpenAI API key
openai.api_key = "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"

def extract_data_from_url(url):
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')

        title = soup.title.text.strip() if soup.title else "N/A"
        meta_description = soup.find("meta", {"name": "description"})
        meta_description = meta_description["content"].strip() if meta_description else "N/A"

        # Extract all paragraphs from the HTML
        paragraphs = [p.text.strip() for p in soup.find_all('p')]
        content = '\n'.join(paragraphs) if paragraphs else "N/A"

        return {
            'title': title,
            'meta_description': meta_description,
            'content': content
        }
    else:
        return None

def summarize_text(text):
    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt=text,
        max_tokens=150
    )
    return response.choices[0].text.strip()


@app.route('/')
def index():
    return render_template('workfile_old1.html')


@app.route('/', methods=['POST'])
def process_query():
    country = request.form['country']
    category = request.form['category']
    subcategory = request.form['subcategory']
    title_prompt = request.form['titlePrompt']
    description_prompt = request.form['descriptionPrompt']

    process_query = f"Fetch latest news for {category} specifically {subcategory} in country {country}"

    url = "https://api.app.outscraper.com/google-search-news"
    params = {"query": process_query, "tds": "d", "async": "false"}
    headers = {"X-API-KEY": "NzE3ZjgyNzllZDdiNDhlZGJkMjcxMDhiYzJkZjg1MDR8NWFmYzg2MmMzNw"}

    response = requests.get(url, params=params, headers=headers)

    if response.status_code == 200:
        data = response.json()
        summaries = []

        for item in data.get("data", [[]])[0]:
            url = item.get("link")
            if url:
                url_data = extract_data_from_url(url)
                if url_data:
                    # Summarize the content
                    summary = summarize_text(f"{url_data['title']}. {url_data['meta_description']}")
                    summaries.append({
                        'url': url,
                        'title': url_data['title'],
                        'meta_description': url_data['meta_description'],
                        'content': url_data['content'],
                        'summary': summary
                    })
                    print(summary)
                else:
                    print(f"Error retrieving data from {url}")


        return render_template('workfile_old1.html', query=process_query, summaries=summaries)
    else:
        return f"Error: {response.status_code} - {response.text}"


if __name__ == '__main__':
    app.run(debug=True)
