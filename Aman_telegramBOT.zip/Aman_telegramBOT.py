import telebot
from telebot import types

API_KEY = '6650519095:AAEdlw5nRrwk-ESwgl0z_vSA5qtc-0oeojg'
bot = telebot.TeleBot(API_KEY)

menu_keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
about_button = types.KeyboardButton("About")
services_button = types.KeyboardButton("Our Services")
projects_button = types.KeyboardButton("Our Projects")
contact_button = types.KeyboardButton("Contact Us")
TeamMembers_button = types.KeyboardButton("Team Members")
Carrer_button = types.KeyboardButton("Carrer")
rate_us_button = types.KeyboardButton("Rate Us")
Previous_button = types.KeyboardButton("<P")
Next_button = types.KeyboardButton("N>")
Back_to_Main_button = types.KeyboardButton("Back to Main Menu")
menu_keyboard.row(about_button, services_button)
menu_keyboard.row(projects_button, contact_button)
menu_keyboard.row(Carrer_button, TeamMembers_button)
menu_keyboard.row(rate_us_button)

star_emoji = "⭐️"

team_members = [
    "1. Pankaj Sharma",
    "2. Aman Sharma",
    "3. Rahul Rangra",
    "4. Amit Bakshi",
    "5. Shilpa",
    "6. Sangita Raniwal",
    "7. Rupali Mandia",
    "8. Gaurav Nanda"
]

current_page = 0
items_per_page = 3

menu_keyboard_team_members = types.ReplyKeyboardMarkup(resize_keyboard=True)
menu_keyboard_team_members.row(Previous_button, Next_button, Back_to_Main_button)

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Welcome to Telegram Bot! How can I assist you?", reply_markup=menu_keyboard)

user_rating = {}
current_menu_state = None

@bot.message_handler(func=lambda message: True)
def handle_menu(message):
    global current_menu_state, current_page

    if message.text == "About":
        bot.send_message(message.chat.id, "This is a simple Telegram bot made by amansrma.")
    elif message.text == "Our Services":
        services_content = "Our Services:\n\n" \
                           "1. Website Design & Development\n" \
                           "2. Mobile App Development\n" \
                           "3. CRM Solutions\n" \
                           "4. Digital Marketing\n" \
                           "5. Social Media Marketing\n" \
                           "6. Search Engine Optimization\n" \
                           "7. ITES Services\n"
        bot.send_message(message.chat.id, services_content)

    elif message.text == "Carrer":
        Carrer_content = "1. PHP Developer (Experience 1-2 Years)\n" \
                         "2. PHP Developer (Fresher)"
        bot.send_message(message.chat.id, Carrer_content)

    elif message.text == "Our Projects":
        projects_content = "Our Projects:\n\n" \
                           "1. https://www.kandere.com\n" \
                           "2. https://www.trackmystack.com\n" \
                           "3. https://www.vikal.com\n" \
                           "4. https://www.sail-la-vie.com\n" \
                           "5. http://www.witkidz.com\n" \
                           "6. https://bestinternetsecurities.com\n" \
                           "7. https://www.worldpathtravel.com\n"
        bot.send_message(message.chat.id, projects_content)

    elif message.text == "Contact Us":
        contact_content = "Contact Us:\n\n" \
                          "Location: S.C.O. 11, First Floor, Industrial Area, Phase 2, Chandigarh, 160002\n" \
                          "Email: info@cyberbells.com\n" \
                          "Phone: +91-98787-87591\n"
        bot.send_message(message.chat.id, contact_content)

    elif message.text == "Team Members":
        send_team_members(message.chat.id, current_page)
        bot.send_message(message.chat.id, "Click any button that you want:", reply_markup=menu_keyboard_team_members)
        current_menu_state = "Team Members"

    elif message.text == "Rate Us":
        markup = types.ReplyKeyboardMarkup(one_time_keyboard=True)
        for i in range(1, 6):
            markup.add(types.KeyboardButton(star_emoji * i))

        bot.send_message(message.chat.id, "Please rate us:", reply_markup=markup)
        user_rating[message.from_user.id] = True

    elif user_rating.get(message.from_user.id) and message.text in [star_emoji * i for i in range(1, 6)]:
        rating = message.text.count(star_emoji)
        bot.send_message(message.chat.id,
                         f"Thank you for giving us {rating}{star_emoji}! Our aim is to do more smart work in this Digital World! Thanks for Supporting Us")
        user_rating[message.from_user.id] = False

    elif message.text == "<P":
        current_page = max(0, current_page - 1)
        send_team_members(message.chat.id, current_page)
        bot.send_message(message.chat.id, "choose next or previous", reply_markup=menu_keyboard_team_members)

    elif message.text == "N>":
        current_page = min(len(team_members) // items_per_page, current_page + 1)
        send_team_members(message.chat.id, current_page)
        bot.send_message(message.chat.id, "choose next or previous:", reply_markup=menu_keyboard_team_members)

    elif message.text == "Back to Main Menu":
        bot.send_message(message.chat.id, "Main Menu!", reply_markup=menu_keyboard)
        current_menu_state = None

    else:
        bot.send_message(message.chat.id, "If you need anything else then:\nChoose an option:", reply_markup=menu_keyboard)

    if current_menu_state != "Team Members":
        current_menu_state = None

def send_team_members(chat_id, page):
    start_index = page * items_per_page
    end_index = (page + 1) * items_per_page
    members_to_display = team_members[start_index:end_index]
    members_content = "\n".join(members_to_display)
    bot.send_message(chat_id, members_content)

bot.polling()