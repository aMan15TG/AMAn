from flask import Flask, request, render_template
import whisper
from moviepy.editor import VideoFileClip

app = Flask(__name__)

def transcribe(video_file):

    video_clip = VideoFileClip(video_file)
    audio_clip = video_clip.audio
    audio_clip.write_audiofile("audio.wav", codec='pcm_s16le')

    model = whisper.load_model("base")
    result = model.transcribe("audio.wav")
    return result["text"]

def save_transcription(text):
    with open("transcription.txt", "w") as file:
        file.write(text)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        video_file = request.files['video']
        video_file.save("input_video.mp4")
        text = transcribe("input_video.mp4")
        save_transcription(text)
        return render_template('vdo_to_txt.html', text=text)
    return render_template('vdo_to_txt.html')

if __name__ == "__main__":
    app.run(debug=True)