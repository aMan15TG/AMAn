import gradio as gr
import whisper
import os

model = whisper.load_model("base")

def transcribe_and_save(video):
    results = model.transcribe(video)
    full_text = results["text"]

    folder_path = "vdo_txt"
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    file_path = os.path.join(folder_path, "transcription.txt")
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(full_text)

    return full_text

iface = gr.Interface(fn=transcribe_and_save,
                     inputs=gr.Video(),
                     outputs="text")
iface.launch()