import User from '../model/userModel.js';
import jwt from 'jsonwebtoken';

// Generate JWT token
const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });
};

export const signup = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const userExist = await User.findOne({ email });
        if (userExist) {
            return res.status(400).json({ message: "User already exists" });
        }

        const user = new User({ name, email, password });
        const savedUser = await user.save();
        const token = generateToken(savedUser._id);

        res.status(201).json({ 
            _id: savedUser._id,
            name: savedUser.name,
            email: savedUser.email,
            token
        });
    } catch (error) {
        console.error("Error in signup method: ", error);
        res.status(500).json({ error: 'Server Error' });
    }
};

export const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });
        if (!user || !(await user.matchPassword(password))) {
            return res.status(401).json({ message: "Invalid email or password" });
        }

        const token = generateToken(user._id);

        res.status(200).json({
            message: "login successful",
            token
        });
    } catch (error) {
        console.error("Error in login method: ", error);
        res.status(500).json({ error: 'Server Error' });
    }
};