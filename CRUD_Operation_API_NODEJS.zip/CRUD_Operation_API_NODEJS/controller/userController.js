import User from '../model/userModel.js';

// Create a new user
export const create = async (req, res) => {
    try {
        const userData = new User(req.body);
        const { email } = userData;

        const userExist = await User.findOne({ email });
        if (userExist) {
            return res.status(400).json({ message: "User already exists" });
        }

        const savedUser = await userData.save();
        res.status(200).json(savedUser);

    } catch (error) {
        console.error("Error in create method: ", error);
        res.status(500).json({ error: 'Server Error' });
    }
};

export const fetch = async (req, res) => {
    try {
        const users = await User.find();
        res.status(200).json(users);
    } catch (error) {
        console.error("Error in fetch method: ", error);
        res.status(500).json({ error: 'Server Error' });
    }
};

export const update = async (req, res) => {
    try {
        const { id } = req.params;
        console.log(`Updating user with ID: ${id}`);
        const updatedUser = await User.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json(updatedUser);
    } catch (error) {
        console.error("Error in update method: ", error);
        res.status(500).json({ error: 'Server Error' });
    }
};

export const remove = async (req, res) => {
    try {
        const { id } = req.params;
        await User.findByIdAndDelete(id);
        res.status(200).json({ message: 'User deleted successfully' });
    } catch (error) {
        console.error("Error in remove method: ", error);
        res.status(500).json({ error: 'Server Error' });
    }
};
