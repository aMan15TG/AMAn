from transformers import VisionEncoderDecoderModel, ViTImageProcessor, AutoTokenizer
import torch
import gradio as gr

model = VisionEncoderDecoderModel.from_pretrained('image_classification_model')
feature_extractor = ViTImageProcessor.from_pretrained('image_classification_model')
tokenizer = AutoTokenizer.from_pretrained('image_classification_model')

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)

max_length = 15
num_beams = 7
gen_kwargs = {'max_length': max_length, 'num_beams': num_beams}

def predict_txt(image):
    pixel_values = feature_extractor(images=[image], return_tensors='pt').pixel_values
    pixel_values = pixel_values.to(device)

    output_ids = model.generate(pixel_values, **gen_kwargs)

    predict = tokenizer.batch_decode(output_ids, skip_special_tokens=True)
    predict = [predic.strip() for predic in predict]
    return predict[0]

iface = gr.Interface(
    fn=predict_txt,
    inputs=gr.Image(type='pil', label='Image'),
    outputs=gr.Text(label='Generated Caption'),
    css=".gradio-container {background: lightgreen; border: 2px solid red; }"
        " #component-9 {position: relative; top: 0px; background: gray; right: 10px;}"
        " #component-4 {background: gray; left: 1px;}"
)

iface.launch(share=True)
