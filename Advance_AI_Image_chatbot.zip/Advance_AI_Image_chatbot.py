from dotenv import load_dotenv
import streamlit as st
import os
from PIL import Image
import google.generativeai as ai
load_dotenv()

ai.configure(api_key= os.getenv('openai_api_key'))
model= ai.GenerativeModel("gemini-pro-vision")

def gemini_response(query, image):
    if query !="":
        response= model.generate_content([query, image])
    else:
        response= model.generate_content(image)
    return response.text

st.set_page_config(page_title= "AI Image Bot")
st. header("AI Bot For Images")

upload_file= st.file_uploader("Choose Image...", type=["jpg", "jpeg", "png", "webp"])
image=" "
if upload_file is not None:
    image= Image.open(upload_file)
    st.image(image, caption="Uploaded_Image.",use_column_width=True)

input = st.text_input("Input :", key="input")
submit= st.button(" GO")
if submit:
    response= gemini_response(input, image)
    st.write(response)

