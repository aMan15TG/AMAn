import telebot
from telebot import types

API_KEY = '6650519095:AAEdlw5nRrwk-ESwgl0z_vSA5qtc-0oeojg'
bot = telebot.TeleBot(API_KEY)

menu_keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
about_button = types.KeyboardButton("About")
services_button = types.KeyboardButton("Our Services")
projects_button = types.KeyboardButton("Our Projects")
contact_button = types.KeyboardButton("Contact Us")
TeamMembers_button = types.KeyboardButton("Team Members")
Carrer_button = types.KeyboardButton("Carrer")
rate_us_button = types.KeyboardButton("Rate Us")
Previous_button = types.KeyboardButton("<P")
Next_button = types.KeyboardButton("N>")
Back_to_Main_button = types.KeyboardButton("Back to Main Menu")
menu_keyboard.row(about_button, services_button)
menu_keyboard.row(projects_button, contact_button)
menu_keyboard.row(Carrer_button, TeamMembers_button)
menu_keyboard.row(rate_us_button)

star_emoji = "⭐️"

team_members = [
    "1. Pankaj Sharma",
    "2. Aman Sharma",
    "3. Rahul Rangra",
    "4. Amit Bakshi",
    "5. Shilpa",
    "6. Sangita Raniwal",
    "7. Rupali Mandia",
    "8. Gaurav Nanda",
    "9. Amit sharma",
    "10. Shilpa sharma",
    "11. Sangita sharma",
    "12. Rupali sharma",
    "13. Gaurav sharma",
    "14. Pankaj Sharma",
    "15. Aman Sharma",
    "16. Rahul Rangra",
    "17. Amit Bakshi",
    "18. Shilpa",
    "19. Sangita Raniwal",
    "20. Rupali Mandia",
    "21. Gaurav Nanda",
    "22. Amit sharma",
    "23. Shilpa sharma",
    "24. Sangita sharma",
    "25. Rupali sharma",
    "26. Gaurav sharma"
]

current_page = 0
items_per_page = 3

menu_keyboard_team_members = types.ReplyKeyboardMarkup(resize_keyboard=True)
menu_keyboard_team_members.row(Back_to_Main_button)


@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Welcome to Telegram Bot! How can I assist you?", reply_markup=menu_keyboard)


user_rating = {}
current_menu_state = None
existing_messages = {}


def get_existing_message_data(chat_id):
    return existing_messages.get(chat_id, {})


def store_message_data(chat_id, message_id, markup):
    existing_messages[chat_id] = {"message_id": message_id, "markup": markup}


@bot.message_handler(func=lambda message: True)
def handle_menu(message):
    global current_menu_state, current_page

    if message.text == "About":
        bot.send_message(message.chat.id, "This is a simple Telegram bot made by amansrma.")
    elif message.text == "Our Services":
        services_content = "Our Services:\n\n" \
                           "1. Website Design & Development\n" \
                           "2. Mobile App Development\n" \
                           "3. CRM Solutions\n" \
                           "4. Digital Marketing\n" \
                           "5. Social Media Marketing\n" \
                           "6. Search Engine Optimization\n" \
                           "7. ITES Services\n"
        bot.send_message(message.chat.id, services_content)

    elif message.text == "Carrer":
        Carrer_content = "1. PHP Developer (Experience 1-2 Years)\n" \
                         "2. PHP Developer (Fresher)"
        bot.send_message(message.chat.id, Carrer_content)

    elif message.text == "Our Projects":
        projects_content = "Our Projects:\n\n" \
                           "1. https://www.kandere.com\n" \
                           "2. https://www.trackmystack.com\n" \
                           "3. https://www.vikal.com\n" \
                           "4. https://www.sail-la-vie.com\n" \
                           "5. http://www.witkidz.com\n" \
                           "6. https://bestinternetsecurities.com\n" \
                           "7. https://www.worldpathtravel.com\n"
        bot.send_message(message.chat.id, projects_content)

    elif message.text == "Contact Us":
        contact_content = "Contact Us:\n\n" \
                          "Location: S.C.O. 11, First Floor, Industrial Area, Phase 2, Chandigarh, 160002\n" \
                          "Email: info@cyberbells.com\n" \
                          "Phone: +91-98787-87591\n"
        bot.send_message(message.chat.id, contact_content)

    elif message.text == "Team Members":
        send_team_members_as_buttons(message.chat.id, current_page)
        bot.send_message(message.chat.id, "Click on a team member:", reply_markup=menu_keyboard_team_members)
        current_menu_state = "Team Members"

    elif message.text == "Rate Us":
        markup = types.ReplyKeyboardMarkup(one_time_keyboard=True)
        for i in range(1, 6):
            markup.add(types.KeyboardButton(star_emoji * i))

        bot.send_message(message.chat.id, "Please rate us:", reply_markup=markup)
        user_rating[message.from_user.id] = True

    elif user_rating.get(message.from_user.id) and message.text in [star_emoji * i for i in range(1, 6)]:
        rating = message.text.count(star_emoji)
        bot.send_message(message.chat.id,
                         f"Thank you for giving us {rating}{star_emoji}! Our aim is to do more smart work in this Digital World! Thanks for Supporting Us")
        user_rating[message.from_user.id] = False

    elif message.text == "<P":
        current_page = max(0, current_page - 1)
        send_team_members_as_buttons(message.chat.id, current_page)
        bot.send_message(message.chat.id, "Choose next or previous", reply_markup=menu_keyboard_team_members)

    elif message.text == "N>":
        current_page = min(len(team_members) // items_per_page, current_page + 1)
        send_team_members_as_buttons(message.chat.id, current_page)
        bot.send_message(message.chat.id, "Choose next or previous:", reply_markup=menu_keyboard_team_members)

    elif message.text == "Back to Main Menu":
        bot.send_message(message.chat.id, "Main Menu!", reply_markup=menu_keyboard)
        current_menu_state = None

    else:
        bot.send_message(message.chat.id, "If you need anything else then:\nChoose an option:",
                         reply_markup=menu_keyboard)

    if current_menu_state != "Team Members":
        current_menu_state = None


def send_team_members_as_buttons(chat_id, page):
    start_index = page * items_per_page
    end_index = (page + 1) * items_per_page
    members_to_display = team_members[start_index:end_index]

    markup = types.InlineKeyboardMarkup(row_width=len(members_to_display))
    for member in members_to_display:
        button = types.InlineKeyboardButton(text=member, callback_data=f"team_member_{member}")
        markup.add(button)

    navigation_buttons = []
    if page > 0:
        navigation_buttons.append(types.InlineKeyboardButton(text="Previous", callback_data="previous"))
    if end_index < len(team_members):
        navigation_buttons.append(types.InlineKeyboardButton(text="Next", callback_data="next"))

    if navigation_buttons:
        markup.row(*navigation_buttons)

    specific_page_buttons = [
        types.InlineKeyboardButton(text="1", callback_data="specific_page_1"),
        types.InlineKeyboardButton(text="2", callback_data="specific_page_2"),
        types.InlineKeyboardButton(text="3", callback_data="specific_page_3"),
        types.InlineKeyboardButton(text="4", callback_data="specific_page_4")
    ]
    markup.row(*specific_page_buttons)

    try:
        existing_message_data = get_existing_message_data(chat_id)
        existing_markup = existing_message_data.get("markup", None)

        if existing_markup != markup:
            existing_message_id = existing_message_data.get("message_id", None)
            if existing_message_id:
                bot.edit_message_text(chat_id=chat_id, message_id=existing_message_id, text="Team Members:",
                                      reply_markup=markup, disable_web_page_preview=True)
                existing_message_data["markup"] = markup
            else:
                new_message = bot.send_message(chat_id, "Team Members:", reply_markup=markup,
                                               disable_web_page_preview=True)
                store_message_data(chat_id, new_message.message_id, markup)
    except Exception as e:
        print(f"Error updating inline keyboard: {e}")

@bot.callback_query_handler(func=lambda call: call.data.startswith('team_member_'))
def handle_team_member_button_callback(call):
    global current_page
    member_name = call.data[len('team_member_'):]
    selected_member_index = team_members.index(member_name)
    current_page = selected_member_index // items_per_page
    existing_message_data = get_existing_message_data(call.message.chat.id)
    existing_page = existing_message_data.get("current_page", None)

    if existing_page is not None and existing_page != current_page:
        current_page = existing_page

    send_team_members_as_buttons(call.message.chat.id, current_page)
    bot.answer_callback_query(call.id, f"You selected {member_name}")

@bot.callback_query_handler(func=lambda call: call.data in ['previous', 'next'])
def handle_navigation_button_callback(call):
    global current_page
    if call.data == 'previous':
        current_page = max(0, current_page - 1)
    elif call.data == 'next':
        current_page = min(len(team_members) // items_per_page, current_page + 1)
    send_team_members_as_buttons(call.message.chat.id, current_page)

@bot.callback_query_handler(func=lambda call: call.data.startswith('specific_page_'))
def handle_specific_page_button_callback(call):
    global current_page
    specific_page = int(call.data[len('specific_page_'):])
    start_index = (specific_page - 1) * items_per_page
    current_page = start_index // items_per_page
    send_team_members_as_buttons(call.message.chat.id, current_page)
    bot.answer_callback_query(call.id, f"Showing members for specific page {specific_page}")

bot.polling()