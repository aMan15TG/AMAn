1> make a folder name (ani_dataset)
2> add two folders in this ani_dataset folder  and follow name :- Cat, Dog
3> add Cat and Dog images in thir respective folder.
4> you need to add this ani_dataset folder (where your python code have in same directory/folder)
5> Enjoy this end-to-end PyTorch project.

THANK YOU