import express from 'express';
import { createServer } from 'http';
import cors from 'cors';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const port = 3000;

const app = express();
app.use(cors({ origin: 'http://localhost:3000' }));

// Serve static files from the root directory
app.use('/avatar', express.static(join(__dirname)));

// Serve the main HTML file
app.get('/avatar', function(req, res) {
    res.sendFile(join(__dirname, 'index.html'));
});

// Serve the agents HTML file
app.get('/agents', function(req, res) {
    res.sendFile(join(__dirname, 'index-agents.html'));
});

const server = createServer(app);

server.listen(port, () => console.log(`Server started on port localhost:${port}`));
