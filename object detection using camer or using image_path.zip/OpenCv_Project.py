import cv2
import numpy as np

def measure_dimensions(reference_length_cm):
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 200)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            x, y, w, h = cv2.boundingRect(largest_contour)
            length_pixels = w
            width_pixels = h
            reference_length_pixels = 100

            pixels_per_cm = reference_length_pixels / reference_length_cm
            length_cm = length_pixels / pixels_per_cm
            width_cm = width_pixels / pixels_per_cm

            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.imshow('Measured Package', frame)

        key = cv2.waitKey(150)
        if key == ord('c'):
            cv2.imwrite('C_images/captured_image.jpg', frame)
            print("Image captured!")
        elif key == ord(' '):
            break

    cap.release()
    cv2.destroyAllWindows()
    return length_cm, width_cm

reference_length_cm = 10
length_cm, width_cm = measure_dimensions(reference_length_cm)
print(f"Length: {length_cm:.2f} cm, Width: {width_cm:.2f} cm")