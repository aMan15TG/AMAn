import cv2
import numpy as np

def measure_dimensions(image_path, reference_length_cm):
    # Load the image from the specified path
    image = cv2.imread(image_path)

    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply GaussianBlur to reduce noise and improve edge detection
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Apply edge detection using Canny
    edges = cv2.Canny(blurred, 50, 150)

    # Find contours in the edges
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Filter contours by area to exclude small objects
    min_contour_area = 500  # Adjust this threshold as needed
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > min_contour_area]

    # Iterate through filtered contours
    for contour in filtered_contours:
        # Find the bounding box of the contour
        x, y, w, h = cv2.boundingRect(contour)

        # Draw the bounding box on the image
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Measure the dimensions in pixels
        length_pixels = w
        width_pixels = h

        # Convert pixel dimensions to real-world dimensions using the reference length
        pixels_per_cm = length_pixels / reference_length_cm
        length_cm = w / pixels_per_cm
        width_cm = h / pixels_per_cm
        height_cm = min(length_cm, width_cm)

        # Print the dimensions for each box
        print(f"Length: {length_cm:.2f} cm, Width: {width_cm:.2f} cm, Height: {height_cm:.2f} cm")

    # Display the image with all the bounding boxes
    cv2.imshow('Measured Packages', image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# Example usage
image_path = 'static/box2.JPEG'  # Replace with the path to your image
reference_length_cm = 10  # Replace with the known reference length in cm

measure_dimensions(image_path, reference_length_cm)