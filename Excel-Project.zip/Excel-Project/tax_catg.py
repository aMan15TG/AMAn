
import xlwings as xw
import requests
import re
import logging
import concurrent.futures
import traceback
from openpyxl.utils import get_column_letter

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# File handler and Console handler
file_handler = logging.FileHandler('tax_catg_log.txt')
file_handler.setLevel(logging.DEBUG)
file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(file_formatter)
logger.addHandler(file_handler)

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
console_handler.setFormatter(console_formatter)
logger.addHandler(console_handler)

# List of tax categories
tax_categories = [
    "Sales", "Commissions received", "Distribution from trusts", "Interest received",
    "FBT contribution", "Stock purchases (GST)", "Purchase (Stock) - GST",
    "Purchase (Stock) - GST Free", "Accounting fee", "Advertising & promotion",
    "Clients gift", "Amortisation expense", "Bank fees & charges", "EFTPOS fees",
    "Merchant fees", "Cleaning & rubbish removal", "Consulting fees",
    "Contract payments", "Depreciation", "Directors fees", "Electricity", "Utilities",
    "Entertainment", "Meals", "Meals & Entertainment", "Meals and Entertainment",
    "Filing fees", "ASIC fees", "Fine", "Penalty", "Insurance", "Interest paid",
    "Laundry", "Uniform", "Lease Payments", "Legal fees", "Licences and Permits",
    "Management fees", "Materials & supplies", "M/V related expense",
    "Motor Vehicle Expenses", "MVE", "Payroll tax paid", "Postage",
    "Printing & stationery", "Office supplies", "Fax", "Books", "Rates & land taxes",
    "Wate rates", "Councl rates", "Rent on land & buildings", "Rent",
    "Repairs & maintenance", "Staff amenities", "Amenities", "Staff training",
    "Conference/Seminar costs", "Education", "Professional Development", "Training",
    "Subscriptions", "Superannuation expense", "Telephone & Internet", "Telephone",
    "Internet", "Website related expense", "Low cost assets", "Computers", "Tools",
    "Public Transport", "Parking", "Travel - domestic", "Taxi", "Tolls", "Accomodation",
    "Travel - international", "Freight and Cartage", "Wages", "Bank Account 1",
    "Bank Account 2", "Bank Account 3", "Bank transfers suspense",
    "Transfer between accounts suspense", "Cash on hand", "Trade debtors",
    "Shares in other companies (Listed)", "Shares in other companies (Unlisted)",
    "SBE Pool", "Less: Accumulated depreciation", "Goodwill", "Preliminary expenses",
    "Less: Accumulated amortisation", "Rental Bond", "Trade creditors",
    "Deposit from Customer (Liability)", "Income Tax Payable",
    "PAYG income instalment payable", "PAYG income instalmet paid",
    "Income Tax paid/refund", "GST payable control account", "GST paid/collected",
    "Superannuation payable", "PAYG withheld payable", "PAYG withhheld paid",
    "BAS payment suspense", "ATO payment suspense", "Director Loans", "Director Loan",
    "Director's Loans", "Drawings", "Suspense", "Hire purhcase repayment",
    "Car loan repayment", "Chattle mortgage repayment", "Income tax on profit",
    "Undistributed Income", "Issued & paid up capital", "Contribution by settlor"
]

# Function to call OpenAI API
def openai_call(transaction_type, entity_and_id, amt):
    try:
        url = "https://api.openai.com/v1/chat/completions"
        api_key = "sk-proj-U2cne6IJ3uUp5EyN1nG2T3BlbkFJZdVcdjhUGtJmb0dhoxav"  
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        
        data = {
            "model": "gpt-3.5-turbo",
            "messages": [
                {"role": "user", "content": f"Transaction Type: {transaction_type}, Entity and ID: {entity_and_id}, Amount: {amt}. Please provide the exact tax category from this list: {', '.join(tax_categories)}. Respond with only the tax category, without any additional text."}
            ],
            "temperature": 0
        }
        
        response = requests.post(url, headers=headers, json=data)
        if response.status_code == 200:
            result = response.json()
            content = result["choices"][0]["message"]["content"].strip()
            logging.info(f"API Response: {content}")
            
            if content in tax_categories:
                return content
            else:
                logging.warning(f"API response '{content}' not in tax categories list.")
                return "Not Found"
        else:
            logging.error(f"API Error: {response.status_code} - {response.reason}")
            return f"Error: {response.status_code} - {response.reason}"
    except Exception as e:
        logging.error(f"Exception during API call: {e}")
        return f"Exception: {str(e)}"

def process_row(row, transaction_type_idx, entity_and_id_idx, amount_idx):
    transaction_type = row[transaction_type_idx]
    entity_and_id = row[entity_and_id_idx]
    amount_str = str(row[amount_idx]).strip()

    try:
        if amount_str:
            if '$' in amount_str:
                amount_str = amount_str.replace('$', '').replace(',', '')
            amount = float(amount_str)
        else:
            amount = None
    except (ValueError, TypeError):
        amount = None

    logging.debug(f"Processing row: Transaction Type={transaction_type}, Entity and ID={entity_and_id}, Amount={amount}")

    if transaction_type and entity_and_id and amount is not None:
        tax_category = openai_call(transaction_type, entity_and_id, amount)
        logging.info(f"Updated row: Transaction Type={transaction_type}, Entity and ID={entity_and_id}, Amount={amount}, Tax Category={tax_category}")
        return tax_category
    else:
        logging.warning(f"Skipping row due to invalid data: Transaction Type={transaction_type}, Entity and ID={entity_and_id}, Amount={amount}")
        return "Invalid data"

def update_tax_category(file_path, batch_size=10):
    try:
        # Open workbook
        wb = xw.Book(file_path)
        
        # Get all sheet names and print them
        sheet_names = wb.sheet_names
        logging.info(f"Sheets in the workbook: {sheet_names}")

        # Try to use the first sheet
        ws = wb.sheets[0]
        logging.info(f"Using sheet: {ws.name}")

        try:
            # Get all data as a 2D list
            data = ws.used_range.options(ndim=2).value
            logging.info(f"Data shape: {len(data)} rows, {len(data[0]) if data else 0} columns")
        except Exception as e:
            logging.error(f"Error reading data from sheet: {e}")
            logging.error(traceback.format_exc())
            return

        if not data:
            logging.error(f"No data found in the sheet: {ws.name}")
            return

        headers = [str(h).strip().lower() for h in data[0]]
        logging.info(f"Found headers: {headers}")

        required_headers = {'transaction type', 'entity and id', 'amount'}
        missing_headers = required_headers - set(headers)
        if missing_headers:
            logging.error(f"Missing required columns. Missing: {missing_headers}")
            return

        transaction_type_idx = headers.index('transaction type')
        entity_and_id_idx = headers.index('entity and id')
        amount_idx = headers.index('amount')
        
        rows = data[1:]  # All rows except headers
        
        # Determine the next blank column for Tax Category
        next_blank_column = ws.used_range.last_cell.column + 1
        column_letter = get_column_letter(next_blank_column)
        ws.range(f"{column_letter}1").value = 'Tax Category'
        logging.debug(f"Next blank column: {column_letter}")

        # Process rows in batches
        for start in range(0, len(rows), batch_size):
            end = start + batch_size
            batch = rows[start:end]

            with concurrent.futures.ThreadPoolExecutor() as executor:
                futures = [executor.submit(process_row, row, transaction_type_idx, entity_and_id_idx, amount_idx) for row in batch]
                tax_categories = [future.result() for future in concurrent.futures.as_completed(futures)]
            
            # Update the Excel sheet with the batch results
            for idx, tax_category in enumerate(tax_categories, start=start + 2):  # start from the appropriate row index
                ws.range(f"{column_letter}{idx}").value = tax_category

            # Save the workbook after processing each batch
            wb.save()
            logging.info(f"Batch from row {start + 1} to {end} processed and saved.")

        logging.info(f"File updated: {file_path}")
    except Exception as e:
        logging.error(f"Exception during Excel processing: {e}")
        logging.error(traceback.format_exc())

file_path = r'C:\Users\lenovo\Downloads\Newfolder\Test_book.xlsm'
update_tax_category(file_path)

print("Script completed. Check the log file for details.")